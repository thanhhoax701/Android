package com.marcinmoskala.arcseekbar;

public interface ProgressListener {
    void invoke(int progress);
}
