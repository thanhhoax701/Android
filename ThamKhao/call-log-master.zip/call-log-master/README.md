call-log
========

Demo application to get all the call history pragmatically from android phone.

